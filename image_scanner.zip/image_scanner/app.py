import os
import hashlib
import base64
import json
from pathlib import Path
from flask import Flask, render_template, jsonify, request, send_file
from PIL import Image
import io
import threading

app = Flask(__name__)

IMAGE_EXTENSIONS = {
    '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp',
    '.tiff', '.tif', '.ico', '.heic', '.heif', '.svg',
    '.raw', '.cr2', '.nef', '.arw', '.dng', '.orf',
    '.ppm', '.pgm', '.pbm', '.avif'
}

scan_progress = {"status": "idle", "current": "", "total": 0, "scanned": 0}
scan_lock = threading.Lock()


def get_md5(filepath):
    hasher = hashlib.md5()
    try:
        with open(filepath, 'rb') as f:
            for chunk in iter(lambda: f.read(65536), b''):
                hasher.update(chunk)
        return hasher.hexdigest()
    except (IOError, PermissionError):
        return None


def get_thumbnail(filepath, size=(200, 200)):
    try:
        with Image.open(filepath) as img:
            img.thumbnail(size, Image.LANCZOS)
            if img.mode in ('RGBA', 'P', 'LA'):
                background = Image.new('RGB', img.size, (30, 30, 30))
                if img.mode == 'P':
                    img = img.convert('RGBA')
                if img.mode in ('RGBA', 'LA'):
                    background.paste(img, mask=img.split()[-1])
                else:
                    background.paste(img)
                img = background
            elif img.mode != 'RGB':
                img = img.convert('RGB')
            buffer = io.BytesIO()
            img.save(buffer, format='JPEG', quality=75)
            buffer.seek(0)
            return base64.b64encode(buffer.read()).decode('utf-8')
    except Exception:
        return None


def get_file_info(filepath):
    try:
        stat = os.stat(filepath)
        size = stat.st_size
        if size < 1024:
            size_str = f"{size} B"
        elif size < 1024 * 1024:
            size_str = f"{size/1024:.1f} KB"
        else:
            size_str = f"{size/1024/1024:.1f} MB"

        width, height = None, None
        try:
            with Image.open(filepath) as img:
                width, height = img.size
        except Exception:
            pass

        return {
            "size": size,
            "size_str": size_str,
            "width": width,
            "height": height,
            "modified": stat.st_mtime
        }
    except Exception:
        return {"size": 0, "size_str": "?", "width": None, "height": None, "modified": 0}


def scan_directory(root_path):
    global scan_progress
    images = []
    hash_map = {}

    all_files = []
    for dirpath, dirnames, filenames in os.walk(root_path):
        # Skip hidden directories
        dirnames[:] = [d for d in dirnames if not d.startswith('.')]
        for filename in filenames:
            ext = Path(filename).suffix.lower()
            if ext in IMAGE_EXTENSIONS:
                all_files.append(os.path.join(dirpath, filename))

    with scan_lock:
        scan_progress["total"] = len(all_files)
        scan_progress["scanned"] = 0
        scan_progress["status"] = "scanning"

    for i, filepath in enumerate(all_files):
        with scan_lock:
            scan_progress["current"] = filepath
            scan_progress["scanned"] = i + 1

        md5 = get_md5(filepath)
        if md5 is None:
            continue

        info = get_file_info(filepath)
        thumbnail = get_thumbnail(filepath)

        image_data = {
            "id": len(images),
            "path": filepath,
            "filename": os.path.basename(filepath),
            "ext": Path(filepath).suffix.lower(),
            "md5": md5,
            "thumbnail": thumbnail,
            **info
        }

        if md5 in hash_map:
            image_data["is_duplicate"] = True
            image_data["duplicate_of"] = hash_map[md5]
            # Mark original as having duplicates
            images[hash_map[md5]]["has_duplicates"] = True
            images[hash_map[md5]]["duplicate_count"] = images[hash_map[md5]].get("duplicate_count", 0) + 1
        else:
            image_data["is_duplicate"] = False
            image_data["has_duplicates"] = False
            image_data["duplicate_count"] = 0
            hash_map[md5] = len(images)

        images.append(image_data)

    with scan_lock:
        scan_progress["status"] = "done"

    return images


scan_results = []
scan_thread = None


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/scan', methods=['POST'])
def start_scan():
    global scan_results, scan_thread, scan_progress

    data = request.json
    path = data.get('path', os.path.expanduser('~'))

    if not os.path.exists(path):
        return jsonify({"error": "Geçersiz dizin yolu"}), 400

    with scan_lock:
        if scan_progress["status"] == "scanning":
            return jsonify({"error": "Tarama zaten devam ediyor"}), 400

    scan_results = []

    def run_scan():
        global scan_results
        scan_results = scan_directory(path)

    scan_thread = threading.Thread(target=run_scan, daemon=True)
    scan_thread.start()

    return jsonify({"status": "started"})


@app.route('/api/progress')
def get_progress():
    with scan_lock:
        return jsonify(scan_progress)


@app.route('/api/results')
def get_results():
    filter_type = request.args.get('filter', 'all')
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 50))

    filtered = scan_results

    if filter_type == 'duplicates':
        filtered = [img for img in scan_results if img['is_duplicate'] or img['has_duplicates']]
    elif filter_type == 'unique':
        filtered = [img for img in scan_results if not img['is_duplicate'] and not img['has_duplicates']]

    total = len(filtered)
    start = (page - 1) * per_page
    end = start + per_page
    paginated = filtered[start:end]

    # Remove thumbnail for listing to reduce payload
    result_list = []
    for img in paginated:
        item = {k: v for k, v in img.items() if k != 'thumbnail'}
        result_list.append(item)

    return jsonify({
        "images": result_list,
        "total": total,
        "page": page,
        "per_page": per_page,
        "total_pages": (total + per_page - 1) // per_page,
        "stats": {
            "total_images": len(scan_results),
            "duplicate_groups": len(set(img['md5'] for img in scan_results if img['is_duplicate'] or img['has_duplicates'])),
            "duplicate_count": sum(1 for img in scan_results if img['is_duplicate']),
            "unique_count": sum(1 for img in scan_results if not img['is_duplicate'])
        }
    })


@app.route('/api/thumbnail/<int:image_id>')
def get_thumbnail_api(image_id):
    if image_id < 0 or image_id >= len(scan_results):
        return jsonify({"error": "Bulunamadı"}), 404
    img = scan_results[image_id]
    if img.get('thumbnail'):
        return jsonify({"thumbnail": img['thumbnail']})
    return jsonify({"thumbnail": None})


@app.route('/api/duplicates')
def get_duplicates():
    groups = {}
    for img in scan_results:
        if img['is_duplicate'] or img['has_duplicates']:
            md5 = img['md5']
            if md5 not in groups:
                groups[md5] = []
            item = {k: v for k, v in img.items() if k != 'thumbnail'}
            groups[md5].append(item)

    return jsonify({"groups": list(groups.values())})


if __name__ == '__main__':
    os.makedirs('templates', exist_ok=True)
    app.run(debug=True, port=5050)
