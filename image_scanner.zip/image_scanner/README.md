# 🖼 Image Scanner

Bilgisayarınızdaki tüm resimleri taran, MD5 hash ile kopyaları tespit eden web uygulaması.

## Kurulum

```bash
pip install -r requirements.txt
```

## Kullanım

```bash
python app.py
```

Tarayıcınızda açın: http://localhost:5050

## Özellikler

- ✅ Tüm resim formatlarını tarar (JPG, PNG, GIF, BMP, WEBP, TIFF, HEIC, RAW, vb.)
- ✅ MD5 hash ile kesin kopya tespiti
- ✅ Kopya gruplarını görsel olarak gösterir
- ✅ Thumbnail önizleme
- ✅ Izgara ve liste görünümü
- ✅ Filtrele: Tümü / Kopyalar / Benzersizler
- ✅ Sayfalama (60 resim/sayfa)
- ✅ Resim detay modalı (boyut, çözünürlük, yol, MD5, tarih)

## Desteklenen Formatlar

.jpg .jpeg .png .gif .bmp .webp .tiff .tif .ico
.heic .heif .svg .raw .cr2 .nef .arw .dng .orf
.ppm .pgm .pbm .avif
